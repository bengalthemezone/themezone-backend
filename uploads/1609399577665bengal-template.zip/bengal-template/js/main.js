$(document).ready(function($) {

    "use strict";

    //WOW JS
    new WOW().init();

    //Portfolio
    var mixer = mixitup('.portfolio-main');

    //Carusel for clients
    $('.client-slider').bxSlider({
        pager: false,
        minSlides: 1,
        maxSlides: 6,
        moveSlides: 2,
        slideWidth: 275,
        slideMargin: 25,
        prevSelector: $('#client-prev'),
        nextSelector: $('#client-next'),
        prevText: '<i class="fa fa-arrow-left"></i>',
        nextText: '<i class="fa fa-arrow-right"></i>'
    });

    //Close New Nav
    $('.close-btn').on('click', function() {
        if ($('.navbar-toggle').css('display') != 'none') {
            $(".navbar-toggle").trigger("click");
        }
    });

    // Smooth Scroll
    $('a[href*="#"]:not([href="#"])').on("click", function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: target.offset().top
                }, 1500);
                return false;
            }
        }
    });

    //Nav menu active class change
    var lastId,
    topMenu = $("#top-menu"),
    topMenuHeight = topMenu.outerHeight() + 15,
    menuItems = topMenu.find("a"),
    scrollItems = menuItems.map(function() {
        var item = $($(this).attr("href"));
        if (item.length) {
            return item;
        }
    });

    $(window).on("scroll", function() {

        // Bind to scroll
        var fromTop = $(this).scrollTop() + topMenuHeight;
        var cur = scrollItems.map(function() {
            if ($(this).offset().top < fromTop)
                return this;
        });
        cur = cur[cur.length - 1];
        var id = cur && cur.length ? cur[0].id : "";
        if (lastId !== id) {
            lastId = id;
            menuItems
                .parent().removeClass("active")
                .end().filter("[href='#" + id + "']").parent().addClass("active");
        }

        //Add class in top-menu
        if ($(window).scrollTop() > 0) {
            $("#top-menu").addClass("new-nav");
        } else {
            $("#top-menu").removeClass("new-nav");
        }

        //Scroll up
        if ($(window).scrollTop() > 300) {
            $('.scrolltotop').slideDown(300);
            $('.scrolltotop').css("display", "block");
        } else {
            $('.scrolltotop').fadeOut(300);
        }
    });

})(jQuery);